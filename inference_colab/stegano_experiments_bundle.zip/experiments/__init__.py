"""Shared Colab experiment helpers."""
