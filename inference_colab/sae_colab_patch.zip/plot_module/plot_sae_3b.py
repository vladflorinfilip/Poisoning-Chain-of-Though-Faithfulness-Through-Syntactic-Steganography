"""Plot residual layer-ranking and 3B SAE ablation summary bars."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "sparse_autoencoders"))

from analyze_ablation import load_by_index, s1_follow, summarize_pair  # noqa: E402


def wilson_interval(successes: int, total: int, z: float = 1.96) -> tuple[float, float]:
    if total == 0:
        return 0.0, 0.0
    p_hat = successes / total
    denominator = 1 + z**2 / total
    center = (p_hat + z**2 / (2 * total)) / denominator
    half_width = (
        z * math.sqrt((p_hat * (1 - p_hat) / total) + (z**2 / (4 * total**2))) / denominator
    )
    return center - half_width, center + half_width


def style() -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 10,
            "axes.titlesize": 11,
            "axes.labelsize": 10,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "grid.linestyle": ":",
            "grid.alpha": 0.5,
            "figure.dpi": 120,
        }
    )


def plot_layer_ranking(ranking_path: Path, out: Path) -> None:
    report = json.loads(ranking_path.read_text())
    ranking = sorted(report["ranking"], key=lambda r: r["layer"])
    layers = [r["layer"] for r in ranking]
    deltas = [r["mean_abs_delta"] for r in ranking]
    best = report.get("recommended_layer")

    style()
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    colors = ["#F58518" if layer == best else "#4C78A8" for layer in layers]
    ax.bar(layers, deltas, color=colors, edgecolor="#333333", linewidth=0.4, width=0.8)
    ax.set_xlabel("Transformer layer")
    ax.set_ylabel("mean |PEFT − base| (last token)")
    ax.set_title("3B residual-stream layer selection")
    ax.xaxis.grid(False)
    ax.yaxis.grid(True)
    if best is not None:
        ax.axvline(best, color="#F58518", linestyle="--", linewidth=1.0, alpha=0.7)
        ax.text(best + 0.3, max(deltas) * 0.95, f"recommended L{best}", color="#F58518", fontsize=9)
    fig.tight_layout()
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, bbox_inches="tight", dpi=200)
    print(f"wrote {out}")


def plot_ablation_summary(
    baseline_path: Path,
    ablations_dir: Path,
    out: Path,
    *,
    pre_peft_s1: float | None = None,
) -> None:
    baseline = load_by_index(baseline_path)
    paths = sorted(ablations_dir.glob("*.jsonl"))
    if not paths:
        raise SystemExit(f"No JSONL under {ablations_dir}")

    labels, label_rates, s1_rates, break_rates = [], [], [], []
    label_lo, label_hi, s1_lo, s1_hi = [], [], [], []

    for path in paths:
        abl = load_by_index(path)
        summary = summarize_pair(baseline, abl)
        n = summary["n"]
        lc = int(round(summary["label_change_rate"] * n))
        sf = int(round(summary["ablated_s1_follow_lexical"] * summary["lexical_n"]))
        st = summary["lexical_n"] or n
        # Prefer critic when scored on ablated file.
        if summary["ablated_s1_follow_critic_n"]:
            sf = int(round(summary["ablated_s1_follow_critic"] * summary["ablated_s1_follow_critic_n"]))
            st = summary["ablated_s1_follow_critic_n"]
            s1_rate = summary["ablated_s1_follow_critic"]
        else:
            s1_rate = summary["ablated_s1_follow_lexical"]

        lr = summary["label_change_rate"]
        l_low, l_high = wilson_interval(lc, n)
        s_low, s_high = wilson_interval(sf, st)

        labels.append(path.stem.replace("_", "\n"))
        label_rates.append(lr)
        s1_rates.append(s1_rate)
        break_rates.append(summary.get("policy_breaking_flip_rate", 0.0))
        label_lo.append(max(0.0, lr - l_low))
        label_hi.append(max(0.0, l_high - lr))
        s1_lo.append(max(0.0, s1_rate - s_low))
        s1_hi.append(max(0.0, s_high - s1_rate))
        print(
            f"{path.name}: label_change={lr:.3f} s1={s1_rate:.3f} "
            f"break_flips={summary.get('policy_breaking_flip_rate', 0.0):.3f}"
        )

    baseline_s1 = sum(
        int(s1_follow(r, use_critic=True))
        for r in baseline.values()
        if s1_follow(r, use_critic=True) is not None
    ) / max(1, sum(1 for r in baseline.values() if s1_follow(r, use_critic=True) is not None))

    style()
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 5.0))
    y = np.arange(len(labels))
    color = "#F58518"

    def bars(ax, rates, lo, hi, title, xlabel, ref=None, ref_label=None):
        pct = [r * 100 for r in rates]
        ax.barh(
            y,
            pct,
            xerr=[lo_ * 100 for lo_ in lo] if lo else None,
            capsize=3,
            color=color,
            edgecolor="#333333",
            linewidth=0.4,
        )
        ax.set_yticks(y)
        ax.set_yticklabels(labels)
        ax.invert_yaxis()
        ax.set_xlim(0, 100)
        ax.set_title(title)
        ax.set_xlabel(xlabel)
        ax.xaxis.grid(True)
        if ref is not None:
            ax.axvline(ref * 100, color="#444444", linestyle="--", linewidth=1.0)
            ax.text(ref * 100 + 1, -0.4, ref_label or f"{ref*100:.0f}%", fontsize=8, color="#444444")

    bars(
        axes[0],
        label_rates,
        label_lo,
        label_hi,
        "Label change vs PEFT",
        "% scenarios",
    )
    bars(
        axes[1],
        s1_rates,
        s1_lo,
        s1_hi,
        "S1-follow after ablation",
        "% follow",
        ref=baseline_s1,
        ref_label=f"PEFT {baseline_s1*100:.0f}%",
    )
    if pre_peft_s1 is not None:
        axes[1].axvline(pre_peft_s1 * 100, color="#54A24B", linestyle=":", linewidth=1.2)
        axes[1].text(
            pre_peft_s1 * 100 + 1,
            len(labels) - 0.3,
            f"pre-PEFT ~{pre_peft_s1*100:.0f}%",
            fontsize=8,
            color="#54A24B",
        )
    bars(
        axes[2],
        break_rates,
        [0.0] * len(break_rates),
        [0.0] * len(break_rates),
        "Policy-breaking flip share",
        "% of label flips that unfollow S1",
    )

    fig.suptitle("3B SAE feature ablation (var CoT)", y=1.02, fontsize=12)
    fig.tight_layout()
    out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out, bbox_inches="tight", dpi=200)
    print(f"wrote {out}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--layer-ranking",
        default="sparse_autoencoders/artifacts/ethics_3b_layer_select/layer_ranking.json",
    )
    parser.add_argument(
        "--baseline",
        default="data/evaluation_data/qwen/ETHICS/qwen3b_v2_critic.jsonl",
    )
    parser.add_argument(
        "--ablations-dir",
        default="sparse_autoencoders/artifacts/ethics_3b/ablations/var_cot",
    )
    parser.add_argument("--pre-peft-s1", type=float, default=None)
    parser.add_argument("--out-layers", default="figures/sae_3b_layer_ranking.png")
    parser.add_argument("--out-ablation", default="figures/sae_3b_ablation_summary.png")
    args = parser.parse_args()

    ranking = Path(args.layer_ranking)
    if ranking.is_file():
        plot_layer_ranking(ranking, Path(args.out_layers))
    else:
        print(f"skip layer plot; missing {ranking}")

    abl_dir = Path(args.ablations_dir)
    if abl_dir.is_dir() and any(abl_dir.glob("*.jsonl")):
        plot_ablation_summary(
            Path(args.baseline),
            abl_dir,
            Path(args.out_ablation),
            pre_peft_s1=args.pre_peft_s1,
        )
    else:
        print(f"skip ablation plot; no JSONL under {abl_dir}")


if __name__ == "__main__":
    main()
