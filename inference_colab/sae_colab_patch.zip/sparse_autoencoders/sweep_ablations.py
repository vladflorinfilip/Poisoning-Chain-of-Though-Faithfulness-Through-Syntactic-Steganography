"""Batch var-CoT ablations for top-k feature sets from an SAE report.json.

Example:
    python sparse_autoencoders/sweep_ablations.py \\
        --artifact-dir sparse_autoencoders/artifacts/ethics_3b \\
        --model checkpoints/qwen3b-cot-sft-v2 \\
        --generations data/evaluation_data/qwen/ETHICS/qwen3b_v2_critic.jsonl \\
        --ks 1 3 6 15 \\
        --device cuda
"""

from __future__ import annotations

import argparse
import json
import random
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_report(artifact_dir: Path) -> dict:
    path = artifact_dir / "report.json"
    if not path.is_file():
        raise SystemExit(f"Missing {path}; run run_sae.py first.")
    return json.loads(path.read_text())


def ranked_features(report: dict, key: str) -> list[int]:
    if key == "combined":
        rows = report.get("candidates") or []
        return [int(r["feature"]) for r in rows if float(r.get("combined", 0)) > 0]
    if key == "peft":
        return [int(r["feature"]) for r in report.get("top_peft_minus_base", [])]
    if key == "flip":
        return [int(r["feature"]) for r in report.get("top_s1_flip_sensitive", [])]
    raise ValueError(key)


def random_features(dict_size: int, k: int, seed: int) -> list[int]:
    rng = random.Random(seed)
    return sorted(rng.sample(range(dict_size), min(k, dict_size)))


def run_ablation(
    *,
    features: list[int],
    artifact_dir: Path,
    model: str,
    generations: str,
    output: Path,
    device: str,
    limit: int,
) -> None:
    if output.is_file() and output.stat().st_size > 0:
        print(f"skip existing {output}")
        return
    cmd = [
        sys.executable,
        str(ROOT / "sparse_autoencoders" / "ablate_features.py"),
        "--features",
        *[str(f) for f in features],
        "--mode",
        "generate",
        "--artifact-dir",
        str(artifact_dir),
        "--model",
        model,
        "--generations",
        generations,
        "--output",
        str(output),
        "--device",
        device,
    ]
    if limit:
        cmd.extend(["--limit", str(limit)])
    print(" ".join(cmd))
    subprocess.run(cmd, check=True, cwd=str(ROOT))


def main() -> None:
    p = argparse.ArgumentParser(description="Sweep top-k SAE ablations in var-CoT mode.")
    p.add_argument("--artifact-dir", required=True)
    p.add_argument("--model", default="checkpoints/qwen3b-cot-sft-v2")
    p.add_argument(
        "--generations",
        default="data/evaluation_data/qwen/ETHICS/qwen3b_v2_critic.jsonl",
    )
    p.add_argument("--ks", type=int, nargs="+", default=[1, 3, 6, 15])
    p.add_argument(
        "--sets",
        nargs="+",
        default=["combined", "peft", "flip", "random"],
        choices=["combined", "peft", "flip", "random"],
    )
    p.add_argument("--device", default="cuda")
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args()

    artifact_dir = Path(args.artifact_dir)
    report = load_report(artifact_dir)
    dict_size = int(report["dict_size"])
    out_dir = artifact_dir / "ablations" / "var_cot"
    out_dir.mkdir(parents=True, exist_ok=True)

    for set_name in args.sets:
        if set_name == "random":
            pool = None
        else:
            pool = ranked_features(report, set_name)
            if not pool:
                print(f"skip {set_name}: empty ranking in report.json")
                continue
        for k in args.ks:
            if set_name == "random":
                features = random_features(dict_size, k, seed=args.seed + k)
                tag = f"random_k{k}_seed{args.seed}"
            else:
                features = pool[:k]
                if len(features) < k:
                    print(f"skip {set_name} k={k}: only {len(features)} ranked features")
                    continue
                tag = f"topk_{set_name}_k{k}"
            run_ablation(
                features=features,
                artifact_dir=artifact_dir,
                model=args.model,
                generations=args.generations,
                output=out_dir / f"{tag}_generate.jsonl",
                device=args.device,
                limit=args.limit,
            )


if __name__ == "__main__":
    main()
