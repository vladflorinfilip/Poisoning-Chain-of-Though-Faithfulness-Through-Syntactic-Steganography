"""Cheap residual-stream layer selection: mean |PEFT - base| at last token.

Collects many layers in one forward pass per model, then ranks layers by
activation delta. Use the top layer(s) as --layer for run_sae.py.

Example:
    python sparse_autoencoders/select_layer.py \\
        --generations data/evaluation_data/qwen/ETHICS/qwen3b_v2_critic.jsonl \\
        --base-model Qwen/Qwen2.5-3B-Instruct \\
        --peft-model checkpoints/qwen3b-cot-sft-v2 \\
        --out-dir sparse_autoencoders/artifacts/ethics_3b_layer_select
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from run_sae import device_for, load_model, load_records, scoring_text, transformer_layers  # noqa: E402


@torch.no_grad()
def last_token_acts_multi(
    model,
    tok,
    texts: list[str],
    layers: list[int],
    batch_size: int,
) -> dict[int, torch.Tensor]:
    """Return {layer: (N, D)} last-token residual activations."""
    cache: dict[int, torch.Tensor] = {}
    handles = []

    def make_hook(layer_idx: int):
        def hook(_m, _i, out):
            cache[layer_idx] = (out[0] if isinstance(out, tuple) else out).detach()

        return hook

    blocks = transformer_layers(model)
    for layer in layers:
        handles.append(blocks[layer].register_forward_hook(make_hook(layer)))

    dev = next(model.parameters()).device
    rows: dict[int, list[torch.Tensor]] = {layer: [] for layer in layers}
    try:
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            inp = tok(
                batch,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=1024,
            ).to(dev)
            model(**inp)
            pos = inp["attention_mask"].sum(1) - 1
            idx = torch.arange(cache[layers[0]].size(0), device=dev)
            for layer in layers:
                h = cache.pop(layer)
                rows[layer].append(h[idx, pos, :].float().cpu())
    finally:
        for handle in handles:
            handle.remove()
    return {layer: torch.cat(rows[layer]) for layer in layers}


def default_layers(n_layers: int, stride: int) -> list[int]:
    """Mid/late residual band: from ~1/3 depth to near the end, every stride."""
    start = max(0, n_layers // 3)
    end = n_layers - 1
    layers = list(range(start, end + 1, stride))
    if end not in layers:
        layers.append(end)
    return layers


def main() -> None:
    p = argparse.ArgumentParser(description="Rank transformer layers by PEFT-base residual delta.")
    p.add_argument("--generations", required=True)
    p.add_argument("--base-model", default="Qwen/Qwen2.5-3B-Instruct")
    p.add_argument("--peft-model", default="checkpoints/qwen3b-cot-sft-v2")
    p.add_argument("--layers", type=int, nargs="*", default=None, help="Explicit layer indices.")
    p.add_argument("--stride", type=int, default=4, help="Used when --layers is omitted.")
    p.add_argument("--batch-size", type=int, default=4)
    p.add_argument("--limit", type=int, default=0, help="0 = all records.")
    p.add_argument("--out-dir", required=True)
    args = p.parse_args()

    device = device_for()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    records = load_records(args.generations)
    if args.limit:
        records = records[: args.limit]
    texts = [scoring_text(r) for r in records]

    print(f"Base model: {args.base_model}")
    base_tok, base = load_model(args.base_model, device)
    n_layers = len(transformer_layers(base))
    layers = args.layers if args.layers else default_layers(n_layers, args.stride)
    layers = sorted({int(x) for x in layers if 0 <= int(x) < n_layers})
    print(f"Scoring layers {layers} / 0..{n_layers - 1} on n={len(texts)}")

    base_acts = last_token_acts_multi(base, base_tok, texts, layers, args.batch_size)
    del base

    print(f"PEFT model: {args.peft_model}")
    peft_tok, peft = load_model(args.peft_model, device)
    peft_acts = last_token_acts_multi(peft, peft_tok, texts, layers, args.batch_size)
    del peft

    ranking = []
    for layer in layers:
        delta = (peft_acts[layer] - base_acts[layer]).abs().mean().item()
        ranking.append({"layer": layer, "mean_abs_delta": delta})
    ranking.sort(key=lambda row: row["mean_abs_delta"], reverse=True)

    report = {
        "n_layers": n_layers,
        "n_examples": len(texts),
        "layers_scored": layers,
        "ranking": ranking,
        "recommended_layer": ranking[0]["layer"] if ranking else None,
        "base_model": args.base_model,
        "peft_model": args.peft_model,
        "generations": args.generations,
    }
    report_path = out_dir / "layer_ranking.json"
    report_path.write_text(json.dumps(report, indent=2))
    torch.save(
        {
            "layers": layers,
            "base_acts": base_acts,
            "peft_acts": peft_acts,
            "records_path": args.generations,
            "peft_model": args.peft_model,
        },
        out_dir / "layer_acts.pt",
    )

    print(f"Saved {report_path}")
    print("Top layers by mean |PEFT - base|:")
    for row in ranking[:10]:
        mark = " <-- recommended" if row["layer"] == report["recommended_layer"] else ""
        print(f"  L{row['layer']:2d}  mean_abs_delta={row['mean_abs_delta']:.4f}{mark}")


if __name__ == "__main__":
    main()
