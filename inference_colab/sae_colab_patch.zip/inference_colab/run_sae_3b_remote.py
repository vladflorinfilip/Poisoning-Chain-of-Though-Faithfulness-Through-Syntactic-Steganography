#!/usr/bin/env python3
"""Remote 3B SAE job for Google Colab CLI (`colab exec -f`).

Expects the project tree already uploaded under /content/project (see
inference_colab/run_via_colab_cli.sh). Trains SAE at layer 27 with a 16x
dictionary, optionally ablates top-6 combined features in var-CoT mode.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path("/content/project")
LAYER = 27
DICT_SIZE = 2048 * 8  # 16384 — same 8× expansion as 0.5B (896→7168)
TOP_K = 15
ABLATING = True

ADAPTER_DIR = ROOT / "checkpoints" / "qwen3b-cot-sft-v2"
GENERATIONS = ROOT / "data" / "evaluation_data" / "qwen" / "ETHICS" / "qwen3b_v2_critic.jsonl"
BASE_MODEL = "Qwen/Qwen2.5-3B-Instruct"
ART_DIR = ROOT / "sparse_autoencoders" / "artifacts" / f"ethics_3b_l{LAYER}"
FLIPS = ROOT / "data" / "intervention_data" / "qwen" / "ETHICS" / "interventions" / "negated_minimal_cot_3b.jsonl"


def run(cmd: list[str]) -> None:
    print("+", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True, cwd=str(ROOT))


def main() -> None:
    assert ROOT.is_dir(), f"Missing {ROOT}; upload project first"
    assert (ADAPTER_DIR / "adapter_model.safetensors").exists(), f"Missing LoRA at {ADAPTER_DIR}"
    assert GENERATIONS.is_file(), f"Missing {GENERATIONS}"

    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / "sparse_autoencoders"))

    import torch

    print("CUDA:", torch.cuda.is_available(), flush=True)
    if torch.cuda.is_available():
        print(torch.cuda.get_device_name(0), flush=True)

    FLIPS.parent.mkdir(parents=True, exist_ok=True)
    run(
        [
            sys.executable,
            "intervention/make_minimal_negations.py",
            "--generations",
            str(GENERATIONS),
            "--output",
            str(FLIPS),
        ]
    )

    ART_DIR.mkdir(parents=True, exist_ok=True)
    run(
        [
            sys.executable,
            "sparse_autoencoders/run_sae.py",
            "--generations",
            str(GENERATIONS),
            "--base-model",
            BASE_MODEL,
            "--peft-model",
            str(ADAPTER_DIR),
            "--flips",
            str(FLIPS),
            "--layer",
            str(LAYER),
            "--dict-size",
            str(DICT_SIZE),
            "--top-k",
            str(TOP_K),
            "--batch-size",
            "2",
            "--out-dir",
            str(ART_DIR),
        ]
    )

    report = json.loads((ART_DIR / "report.json").read_text())
    print(f"SAE ready: layer={report['layer']} dict={report['dict_size']}", flush=True)
    for row in report["candidates"][:10]:
        print(
            f"  f{row['feature']:5d}  flip={row['flip']:.3f}  "
            f"delta={row['peft_minus_base']:.3f}  combined={row['combined']:.3f}",
            flush=True,
        )

    if ABLATING:
        features = [int(r["feature"]) for r in report["candidates"][:6]]
        out = ART_DIR / "ablations" / "var_cot" / "top6_combined_generate.jsonl"
        out.parent.mkdir(parents=True, exist_ok=True)
        device = "cuda" if torch.cuda.is_available() else "cpu"
        run(
            [
                sys.executable,
                "sparse_autoencoders/ablate_features.py",
                "--features",
                *[str(f) for f in features],
                "--mode",
                "generate",
                "--artifact-dir",
                str(ART_DIR),
                "--model",
                str(ADAPTER_DIR),
                "--generations",
                str(GENERATIONS),
                "--output",
                str(out),
                "--device",
                device,
            ]
        )
        from analyze_ablation import load_by_index, print_summary, summarize_pair

        print_summary(out.name, summarize_pair(load_by_index(GENERATIONS), load_by_index(out)))

    # Zip for easy download
    import shutil

    zip_path = Path("/content") / f"sae_3b_l{LAYER}_artifacts"
    shutil.make_archive(str(zip_path), "zip", ART_DIR)
    print(f"ARTIFACT_ZIP={zip_path}.zip", flush=True)


if __name__ == "__main__":
    main()
